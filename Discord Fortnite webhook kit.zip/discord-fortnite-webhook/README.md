# 🎙️ RAGEQUEEN42088 NEWS DESK → Discord

Posts the latest Fortnite in-game news (and brand-new Item Shop drops) into a
Discord channel automatically, every 30 minutes, using a Discord webhook +
GitHub Actions. News source: the free [fortnite-api.com](https://fortnite-api.com) — no API key needed.

## Setup (about 10 minutes, one time)

### 1. Make the Discord webhook
1. Open Discord and go to the server + channel where the news should land.
2. **Server Settings → Integrations → Webhooks → New Webhook**
3. Name it `RAGEQUEEN42088 NEWS DESK`, pick the channel, **Copy Webhook URL**.
   ⚠️ Keep this URL secret — anyone with it can post to your channel.

### 2. Make the GitHub repo
1. On GitHub: **New repository**, name it e.g. `fortnite-news-webhook`.
2. Upload/add the three files from this folder, keeping the folders as they are:
   - `fortnite_discord_bot.py`
   - `seen.json`
   - `.github/workflows/fortnite-news.yml`

### 3. Add the webhook as a secret
1. In the repo: **Settings → Secrets and variables → Actions → New repository secret**
2. Name: `DISCORD_WEBHOOK_URL` — Value: paste the webhook URL from step 1. Save.

### 4. Turn it on
1. Go to the repo's **Actions** tab and enable workflows if GitHub asks.
2. Pick **Fortnite News to Discord → Run workflow** to do a test run.
3. Watch your Discord channel — the current news posts should appear.
   After the test, it runs itself every 30 minutes and only posts NEW items
   (it remembers what it already posted in `seen.json`).

## Handy tweaks (in fortnite_discord_bot.py)
- `POST_SHOP_NEWS = False` → news only, no shop posts.
- `MAX_POSTS_PER_RUN` → how many posts one run may send (default 10).
- Want it faster/slower? Change the cron line in the workflow file
  (`*/30` = every 30 minutes; GitHub's minimum is every 5 minutes).

## If something breaks
- **Nothing posts:** check Actions tab → latest run → red X usually means the
  secret name is wrong or the webhook URL was deleted in Discord.
- **Everything re-posts:** `seen.json` got deleted/reset — it will calm down
  after one run.
- **Webhook URL leaked:** Discord → Integrations → delete the webhook, make a
  new one, update the GitHub secret.
