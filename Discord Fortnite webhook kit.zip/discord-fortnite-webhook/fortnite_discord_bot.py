"""
RAGEQUEEN42088 NEWS DESK -> Discord
Fetches the latest Fortnite news (and brand-new shop items) from the free
fortnite-api.com and posts anything new to a Discord channel via webhook.

Runs on GitHub Actions (see .github/workflows/fortnite-news.yml).
The webhook URL comes from the DISCORD_WEBHOOK_URL secret - never hard-code it.
Already-posted items are remembered in seen.json so nothing posts twice.
"""

import json
import os
import time
import urllib.request

WEBHOOK = os.environ["DISCORD_WEBHOOK_URL"]
NEWS_URL = "https://fortnite-api.com/v2/news"
SHOP_URL = "https://fortnite-api.com/v2/shop"
SEEN_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "seen.json")

POST_SHOP_NEWS = True   # set False if you only want the news tab posts
MAX_POSTS_PER_RUN = 10  # safety cap so one run never floods the channel


def get_json(url):
    req = urllib.request.Request(url, headers={"User-Agent": "ragequeen-newsdesk"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        return json.loads(resp.read().decode("utf-8"))


def post_to_discord(title, description, image_url=None, color=0xFF7EB6):
    embed = {"title": title, "description": description, "color": color}
    if image_url:
        embed["image"] = {"url": image_url}
    payload = {
        "username": "RAGEQUEEN42088 NEWS DESK",
        "embeds": [embed],
    }
    req = urllib.request.Request(
        WEBHOOK,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        resp.read()
    time.sleep(1)  # be kind to Discord's rate limits


def load_seen():
    if os.path.exists(SEEN_FILE):
        with open(SEEN_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_seen(seen):
    with open(SEEN_FILE, "w", encoding="utf-8") as f:
        json.dump(seen, f, indent=2, sort_keys=True)


def main():
    seen = load_seen()
    posted = 0

    # --- 1) Fortnite in-game news (BR news tab) ---
    try:
        news = get_json(NEWS_URL)
        motds = (news.get("data") or {}).get("br", {}).get("motds", []) or []
        for motd in motds:
            if posted >= MAX_POSTS_PER_RUN:
                break
            key = "news:" + str(motd.get("id"))
            if key in seen:
                continue
            title = motd.get("title") or "Fortnite News"
            body = motd.get("body") or ""
            image = motd.get("image") or motd.get("tabTitleOverride")
            post_to_discord(f"🎙️ {title}", body[:1500], image if isinstance(image, str) else None)
            seen[key] = True
            posted += 1
            print("posted news:", title)
    except Exception as e:
        print("news fetch failed:", e)

    # --- 2) Brand-new item shop entries ---
    if POST_SHOP_NEWS:
        try:
            shop = get_json(SHOP_URL)
            data = shop.get("data") or {}
            entries = []
            for section in ("featured", "daily", "specialFeatured"):
                part = data.get(section) or {}
                entries.extend(part.get("entries", []) or [])
            for entry in entries:
                if posted >= MAX_POSTS_PER_RUN:
                    break
                key = "shop:" + str(entry.get("offerId"))
                if key in seen:
                    continue
                name = entry.get("bundle", {}).get("name") if entry.get("bundle") else None
                items = entry.get("items", []) or []
                if not name and items:
                    name = items[0].get("name")
                if not name:
                    name = "New item in the shop"
                price = entry.get("finalPrice")
                image = None
                if items:
                    images = items[0].get("images", {}) or {}
                    image = images.get("featured") or images.get("icon")
                desc = f"Just hit the Item Shop: **{name}**"
                if price is not None:
                    desc += f" — {price} V-Bucks"
                post_to_discord("🛒 NEW IN THE SHOP", desc, image, color=0x5EC8FF)
                seen[key] = True
                posted += 1
                print("posted shop item:", name)
        except Exception as e:
            print("shop fetch failed:", e)

    save_seen(seen)
    print(f"done. {posted} new post(s) this run.")


if __name__ == "__main__":
    main()
